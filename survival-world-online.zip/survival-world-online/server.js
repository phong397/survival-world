const express = require("express");
const http = require("http");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");
const { Server } = require("socket.io");

const PORT = Number(process.env.PORT || 3000);
const ADMIN_KEY = process.env.ADMIN_KEY || "doi-mat-khau-admin-ngay";
const DATA_FILE = path.join(__dirname, "data.json");

function loadData() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return { users: {}, giftcodes: {} }; }
}
const db = loadData();
function saveData() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
}
const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.json({ limit: "20kb" }));
const sessionMiddleware = session({
  secret: process.env.SESSION_SECRET || "change-this-session-secret",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", maxAge: 7 * 24 * 3600 * 1000 }
});
app.use(sessionMiddleware);
io.engine.use(sessionMiddleware);
app.use(express.static(path.join(__dirname, "public")));

const online = new Map();
const worlds = new Map();
const cleanName = s => String(s || "").trim().replace(/[^\p{L}\p{N}_-]/gu, "").slice(0, 16);
const publicUser = u => ({
  username: u.username, coins: u.coins, xp: u.xp, level: u.level,
  banned: !!u.banned
});
function requireAuth(req, res, next) {
  const u = req.session.username && db.users[req.session.username];
  if (!u || u.banned) return res.status(401).json({ error: "Vui lòng đăng nhập lại." });
  req.user = u; next();
}
function addXP(u, n) {
  u.xp += n;
  while (u.xp >= u.level * 100) { u.xp -= u.level * 100; u.level++; u.coins += 10; }
}
app.post("/api/register", async (req, res) => {
  const username = cleanName(req.body.username);
  const password = String(req.body.password || "");
  if (username.length < 3 || password.length < 6)
    return res.status(400).json({ error: "Tên cần 3 ký tự, mật khẩu ít nhất 6 ký tự." });
  if (db.users[username]) return res.status(409).json({ error: "Tên này đã được sử dụng." });
  db.users[username] = {
    username, password: await bcrypt.hash(password, 10), coins: 50, xp: 0, level: 1,
    banned: false, inventory: { wood: 0, stone: 0, berry: 2, potion: 0 },
    health: 100, hunger: 100, redeemed: []
  };
  saveData(); req.session.username = username;
  res.json({ user: publicUser(db.users[username]) });
});
app.post("/api/login", async (req, res) => {
  const username = cleanName(req.body.username);
  const u = db.users[username];
  if (!u || !(await bcrypt.compare(String(req.body.password || ""), u.password)))
    return res.status(401).json({ error: "Sai tên đăng nhập hoặc mật khẩu." });
  if (u.banned) return res.status(403).json({ error: "Tài khoản đã bị khóa." });
  req.session.username = username;
  res.json({ user: publicUser(u) });
});
app.post("/api/logout", (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get("/api/me", requireAuth, (req, res) => {
  const u = req.user;
  res.json({ user: publicUser(u), inventory: u.inventory, health: u.health, hunger: u.hunger });
});
app.get("/api/leaderboard", (req, res) => {
  res.json(Object.values(db.users).filter(u => !u.banned)
    .sort((a,b) => b.level-a.level || b.coins-a.coins).slice(0,10)
    .map(u => ({ username:u.username, level:u.level, coins:u.coins })));
});
app.post("/api/redeem", requireAuth, (req, res) => {
  const code = String(req.body.code || "").trim().toUpperCase();
  const gift = db.giftcodes[code], u = req.user;
  if (!gift || gift.remaining <= 0) return res.status(404).json({ error: "Giftcode không hợp lệ hoặc đã hết lượt." });
  if (u.redeemed.includes(code)) return res.status(409).json({ error: "Bạn đã dùng giftcode này." });
  gift.remaining--; u.redeemed.push(code); u.coins += gift.coins; addXP(u, gift.xp);
  saveData(); res.json({ message: `Nhận ${gift.coins} xu và ${gift.xp} XP!`, user: publicUser(u) });
});
app.post("/api/admin", requireAuth, (req, res) => {
  if (String(req.body.key || "") !== ADMIN_KEY) return res.status(403).json({ error: "Sai mã admin." });
  const action = req.body.action;
  if (action === "gift") {
    const code = String(req.body.code || "").trim().toUpperCase().replace(/[^A-Z0-9_-]/g, "").slice(0,24);
    const coins = Math.max(0, Math.min(100000, Number(req.body.coins) || 0));
    const xp = Math.max(0, Math.min(100000, Number(req.body.xp) || 0));
    const remaining = Math.max(1, Math.min(100000, Number(req.body.remaining) || 1));
    if (!code) return res.status(400).json({ error: "Mã không hợp lệ." });
    db.giftcodes[code] = { coins, xp, remaining }; saveData();
    return res.json({ message: `Đã tạo giftcode ${code}.` });
  }
  if (action === "ban" || action === "unban") {
    const target = cleanName(req.body.username);
    if (!db.users[target]) return res.status(404).json({ error: "Không tìm thấy người chơi." });
    db.users[target].banned = action === "ban"; saveData();
    return res.json({ message: `Đã ${action === "ban" ? "khóa" : "mở khóa"} ${target}.` });
  }
  if (action === "coins") {
    const target = cleanName(req.body.username);
    if (!db.users[target]) return res.status(404).json({ error: "Không tìm thấy người chơi." });
    db.users[target].coins = Math.max(0, Math.min(10000000, Number(req.body.amount) || 0));
    saveData(); return res.json({ message: "Đã cập nhật xu." });
  }
  res.status(400).json({ error: "Lệnh admin không hợp lệ." });
});

function playerView(username) {
  const p = worlds.get(username);
  return p ? { username, x:p.x, y:p.y, health:p.health, level:db.users[username]?.level || 1 } : null;
}
function broadcastWorld() {
  io.emit("world", [...worlds.keys()].map(playerView).filter(Boolean));
}
io.use((socket, next) => {
  const username = socket.request.session?.username;
  if (!username || !db.users[username] || db.users[username].banned) return next(new Error("Bạn cần đăng nhập."));
  socket.username = username; next();
});
io.on("connection", socket => {
  const username = socket.request.session?.username || socket.handshake.auth?.username;
  const u = db.users[username];
  if (!u || u.banned) { socket.disconnect(true); return; }
  socket.username = username;
  if (!worlds.has(username)) worlds.set(username, { x: 400 + Math.random()*200, y: 300 + Math.random()*120, health:u.health });
  online.set(username, socket.id);
  socket.emit("chat", { system: true, text: "Chào mừng đến Survival World!" });
  broadcastWorld();
  socket.on("move", data => {
    const p = worlds.get(username); if (!p) return;
    const dx = Math.max(-1, Math.min(1, Number(data?.dx) || 0));
    const dy = Math.max(-1, Math.min(1, Number(data?.dy) || 0));
    p.x = Math.max(20, Math.min(780, p.x + dx*8));
    p.y = Math.max(20, Math.min(580, p.y + dy*8));
    broadcastWorld();
  });
  socket.on("chat", msg => {
    const text = String(msg || "").trim().slice(0,120);
    if (text) io.emit("chat", { username, text });
  });
  socket.on("gather", kind => {
    const allowed = ["wood","stone","berry"];
    if (!allowed.includes(kind)) return;
    const amount = kind === "berry" ? 1 : 2;
    u.inventory[kind] = (u.inventory[kind] || 0) + amount;
    addXP(u, 5); saveData();
    socket.emit("notice", `Nhặt được ${amount} ${kind === "wood" ? "gỗ" : kind === "stone" ? "đá" : "quả mọng"} (+5 XP)`);
    socket.emit("stats", { inventory:u.inventory, user:publicUser(u) });
  });
  socket.on("craft", item => {
    if (item === "potion" && u.inventory.berry >= 2 && u.inventory.wood >= 1) {
      u.inventory.berry -= 2; u.inventory.wood -= 1; u.inventory.potion++;
      saveData(); socket.emit("notice","Đã chế tạo 1 bình hồi máu.");
      socket.emit("stats",{inventory:u.inventory,user:publicUser(u)});
    } else socket.emit("notice","Không đủ nguyên liệu (2 quả mọng + 1 gỗ).");
  });
  socket.on("usePotion", () => {
    if (u.inventory.potion > 0 && u.health < 100) {
      u.inventory.potion--; u.health = Math.min(100,u.health+35);
      const p = worlds.get(username); if (p) p.health = u.health;
      saveData(); socket.emit("notice","Đã hồi 35 máu.");
      socket.emit("stats",{inventory:u.inventory,user:publicUser(u),health:u.health});
      broadcastWorld();
    }
  });
  socket.on("disconnect", () => {
    if (online.get(username) === socket.id) { online.delete(username); worlds.delete(username); broadcastWorld(); }
  });
});
setInterval(() => {
  for (const [name, u] of Object.entries(db.users)) {
    if (!online.has(name) || u.banned) continue;
    u.hunger = Math.max(0, u.hunger - 1);
    if (u.hunger === 0) u.health = Math.max(0, u.health - 2);
    if (u.health === 0) { u.health = 100; u.hunger = 60; }
    const p = worlds.get(name); if (p) p.health = u.health;
    const s = io.sockets.sockets.get(online.get(name));
    if (s) s.emit("stats", { health:u.health, hunger:u.hunger, inventory:u.inventory, user:publicUser(u) });
  }
  saveData();
}, 10000);

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Survival World đang chạy: http://127.0.0.1:${PORT}`);
  console.log("Đổi ADMIN_KEY và SESSION_SECRET trước khi mở Internet.");
});
