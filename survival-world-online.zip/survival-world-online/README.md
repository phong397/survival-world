# SURVIVAL WORLD ONLINE — Termux

## 1. Cài Node.js trên Termux
Mở Termux và chạy:

```bash
pkg update -y && pkg upgrade -y
pkg install nodejs-lts unzip -y
```

## 2. Giải nén và cài thư viện
Chép file ZIP vào thư mục Download của điện thoại, sau đó:

```bash
termux-setup-storage
cd ~/storage/downloads
unzip survival-world-online.zip
cd survival-world-online
npm install
```

Nếu ZIP được giải nén ở thư mục khác, dùng `cd` tới đúng thư mục có `server.js`.

## 3. Đặt khóa admin và chạy
```bash
export ADMIN_KEY='DoiMatKhauAdmin_RatDai_123!'
export SESSION_SECRET='MotChuoiBiMatDaiVaNgauNhien_456!'
npm start
```

Giữ Termux mở. Trên điện thoại, mở Chrome và vào:
`http://127.0.0.1:3000`

## 4. Tạo tài khoản và chơi
- Bấm **Đăng ký**, tạo tài khoản rồi đăng nhập.
- Dùng nút mũi tên hoặc WASD để di chuyển.
- Nhặt gỗ, đá, quả mọng; chế bình hồi máu.
- Nhiều người có thể cùng vào nếu họ truy cập được địa chỉ máy chủ.

## 5. Admin
Đăng nhập tài khoản thường, kéo xuống phần **Admin**, nhập đúng `ADMIN_KEY`, rồi tạo giftcode.
Các API quản trị hỗ trợ thêm:
- `action: "ban"` hoặc `"unban"` kèm `username`
- `action: "coins"` kèm `username` và `amount`

## 6. Chơi online qua Internet
`127.0.0.1` chỉ dùng trên chính điện thoại. Để bạn bè ngoài mạng truy cập, cần:
- Máy chủ có IP công khai/hosting, hoặc
- Dịch vụ tunnel TCP/HTTP phù hợp để đưa cổng 3000 ra Internet.

Không chia sẻ `ADMIN_KEY`, `SESSION_SECRET` hoặc file `data.json`. Không nên dùng máy chủ thử nghiệm này cho dữ liệu/tài khoản quan trọng. Trước khi mở Internet, hãy đổi cả hai khóa bí mật và dùng HTTPS qua reverse proxy/tunnel đáng tin cậy.

## Lưu ý về bản 1.0
Đây là bản MVP chơi được: tài khoản, lưu dữ liệu JSON, nhiều người cùng thấy nhau, di chuyển, chat, nhặt tài nguyên, chế tạo, đói/máu, giftcode, leaderboard và API admin. Chưa có bản đồ lưu bền vững, PvP, quái vật AI, giao dịch giữa người chơi hay chống gian lận cấp production. Session mặc định dùng MemoryStore nên đăng nhập có thể mất khi khởi động lại server.
